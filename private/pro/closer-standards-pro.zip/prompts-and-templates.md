# The Closer's Standards, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are building a closer's operating system for one rep or one team. Read CONTEXT, then THE STANDARDS, then follow BUILD. Ask me up to five questions first if CONTEXT is thin. Use only my facts. No pressure tactics, no invented claims.

CONTEXT
- What we sell and the verified facts: [ ]
- Medium: [ ]
- The twenty objections we hear most, in the customer's words: [ ]
- What our pitch says today about price, timing, and commitment: [ ]
- Our follow-up channels (text, email, call) and the typical gap between conversations: [ ]
- Commission structure, and my last six months of commission if I want the money plan: [ ]
- Words we use: [ ]   Words we never use: [ ]

THE STANDARDS
In the conversation: pre-handle instead of rebutting (raise the doubt first, in your words, inside the pitch); leave with a hard yes, a hard no, or a conditional yes with a date; never send "just following up"; proof is the whole thing (show, do not describe); practice the moment, not the movie. With the money: no sales math (record month times twelve is not a salary), no vanity math (the story lasts a day, the bill lasts a year), protect the days after a heavy night, stack the skill before the trappings, respect the boring layer under any tool you build.

BUILD
1. PRE-HANDLE LINES: for each of my twenty objections, the line that raises and answers it inside the pitch before the customer says it, and where in the pitch it goes (open, story, show, ask, lock).
2. THE FOLLOW-UP LIBRARY: twelve messages for my channels, each naming what the customer said the decision depends on, what changed, one small next step, and a date. Label which situation each is for.
3. THE CONDITIONAL YES: the script for turning "let me think about it" into a yes with named conditions and a hard time to meet them.
4. THE HARD NO EXIT: two sentences that take the no, keep the relationship, and leave one door open.
5. THE WEEKLY AUDIT: ten yes-or-no questions in my words.
6. THE COMMISSION PLAN (if I gave numbers): my six-month average, the monthly budget built on it, the savings rule for anything above it, and the purchase test (does this buy a use or a story).
7. QUIZ MODE: twenty short conversation endings; for each, the standard that was broken and the line that would have fixed it.

Rules: plain language, no hype, no dashes, mark assumptions [CHECK].
```

## 1. Pre-handling, in practice

```
PRE-HANDLE FINDER. Here is a transcript. List every objection that was spoken, and for each, the line that would have raised and answered it earlier inside the pitch, and where it belongs. TRANSCRIPT: [paste]
```
