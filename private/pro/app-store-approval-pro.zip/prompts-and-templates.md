# App Store Approval, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the readiness prompt

```
You are scoring an iOS app for App Store review readiness. Read CONTEXT, then THE CHECKLIST, then produce THE SCORECARD. Use only what I tell you. Where you cannot tell from my description, mark the item UNKNOWN and tell me what to check. Explain what each failing item means and why the rule exists. Do not give implementation steps.

CONTEXT
- What the app does and for whom: [ ]
- What people buy inside it, if anything, and whether it is digital (used in the app) or physical or a service used outside the app: [ ]
- How people pay today (in-app purchase, a card form, a web checkout, nothing): [ ]
- Accounts: can people create one, delete one inside the app, sign in with a third party: [ ]
- User content: can people post, message, share, or see each other: [ ]
- Devices: iPhone only, or iPad too; portrait only or both: [ ]
- What is unfinished, placeholder, or coming soon: [ ]
- Screenshots: from which build, and do any show paid features: [ ]
- Links in the app and listing (privacy policy, support, terms): [ ]
- Demo account for review: exists, works, in the review notes: [ ]

THE CHECKLIST (forty items, grouped)
Money: digital purchases use in-app purchase; physical goods and outside services may use a card or web checkout; no links or buttons that steer digital purchases outside the app except where Apple's current rules allow; restore purchases works for anything that persists; subscription terms, price, and renewal shown before purchase; free trial terms clear; no purchase required to see what the app does.
Accounts: Sign in with Apple (or an equivalent that limits data) offered whenever a third-party social login is offered; account deletion inside the app, not by email; accounts not required for features that do not need them; privacy policy linked in app and listing; data collection matches the privacy labels.
Completeness: demo credentials in review notes and working; no crashes on launch or common paths; no coming soon, placeholder, or empty screens; every link resolves; the app is more than a web page in a frame; permissions requested with a clear reason at the moment of need; no references to other platforms' pricing or stores.
iPad and design: installs and runs on iPad if universal; layouts hold in both orientations if both are supported; text and buttons not cut off; no stretched iPhone UI; iPad screenshots are real iPad screenshots.
Metadata: screenshots from the current build; every feature shown exists; paid features shown are marked as paid; description does not promise features that do not exist; app name and subtitle not keyword stuffed; age rating matches content; support URL and marketing URL resolve.
Safety: report content, block users, and a way to contact you if there is any user-generated content; no content the rating does not allow; no hidden features or functionality that changes after review; health, finance, and kids categories meet their extra rules.

THE SCORECARD
For every item: PASS, FAIL, or UNKNOWN, with one line. Then: the items most likely to send the app back, in order; what each rule protects; and the three questions to answer before submitting. End with a readiness score out of forty.
```

## 1. The payment decision tree

```
REJECTION REPLY. Here is the rejection message. Write my resolution-center reply in under 120 words: what the reviewer flagged, what I changed, where they can see it, and the demo steps. No argument, no apology, just the fix. REJECTION: [paste]  WHAT I CHANGED: [paste]
```
