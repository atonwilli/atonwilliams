# Building Your Own App, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the scoping prompt

```
You are scoping an app build for someone who will build with AI. Read CONTEXT, then THE MAP, then produce THE PLAN. Use only what I tell you. Explain what each thing is and why it is needed. Do not write code or step-by-step commands; the agent does that.

CONTEXT
- The app, in one sentence, and who it is for: [ ]
- Where money and data live (accounts, payments, what must be stored): [ ]
- Stores: iPhone, Android, both, or web first: [ ]
- My machine (Mac or Windows) and my comfort with a terminal: [ ]
- Tools and accounts I already have: [ ]
- Budget per month for tools and models: [ ]
- Is this for my own business, or a product for others: [ ]

THE MAP
Five kinds of tools: a place to write and run code (Claude Code in the terminal; Cursor or VS Code as an editor), the platform kit (Xcode for iOS on a Mac, Android Studio for Android, both with simulators), a cross-platform layer when one codebase should ship to both (Expo with React Native), a backend (a hosted database with authentication, plus a payment provider), and version control (GitHub). Connectors (MCP servers) are bridges from the AI to a service: repository, database, payments, browser. Keys live in environment variables, never in files the AI writes. Three levels of letting the AI drive: it writes and you paste; it works inside the project and asks before anything that matters; it drives the browser or desktop through a connector. Models: strongest for planning and review, efficient for the volume of slices, cheapest for repetitive checks. The boring layer (support, testing, monitoring, backups, access control, a data model) is what separates a prototype from a product.

THE PLAN
1. THE TOOLS for my case, in install order, with one line on why each and why that order.
2. THE CONNECTORS I need, what each door opens, and the key-handling rule for each.
3. THE MODELS: which plans, which builds, which checks, and a rough monthly cost at my build size.
4. THE LET-IT-DRIVE RULES for my project: what the AI may do alone, what waits for me.
5. BUILD ORDER: the first five slices, the first thing a real user should see, and the boring-layer items before real customers.
6. THE HONEST CALL: weekend build, weeks of evenings, or a project to hire, and why.
7. THE BRIEF: a one-page project brief in the template (what is real when done, who uses it, what it must never do, the three laws, the definition of done).
```
