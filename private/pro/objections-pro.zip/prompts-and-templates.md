# Objections, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## 1. The five-second test

```
Build an objection bank for the product below. I want forty objections a real customer would raise, sorted into REFLEX (no specific noun, could be said to anyone) and REASON (contains a specific concern), and for reasons, tagged COST, QUALITY, or VALUE.

For each objection give: the line as a customer would say it, the classification, the answer (three-word nod plus a question for reflexes; validate, normalize, pivot for reasons), and one rebuild line that uses only the product facts provided.

Rules: use only the facts below, never invent capabilities, never disparage competitors, include at least five objections that should END the conversation and say so.

Product facts: [paste]
Medium: [retail / phone / meeting]
Customer type: [describe]
```

## Prompt B. Sparring partner

```
You are a customer raising objections so a rep can practice. Medium: [ ]. Product category: [ ]. Your real reason for hesitating, which you will only reveal if the rep handles a reflex well and asks a genuine question: [ ].

Start with a reflex. If the rep argues with it, escalate. If the rep nods and asks a question, answer it and raise your real reason. If the rep validates, normalizes, and pivots, soften. If they skip a step, repeat the objection in different words.

Stay in character until STOP. Then give: which objections were reflexes and which were reasons, whether the rep diagnosed each correctly, and the single line to change.
```

## Prompt C. Answer grader

```
Grade these objection answers. For each: was the objection a reflex or a reason, did the rep treat it correctly, did the answer contain the right structure (three-word nod plus question, or validate, normalize, pivot, rebuild), did the rebuild match the angle (cost, quality, value), and did the rep ever argue, pressure, or invent a claim. Score each out of five and give the rewritten answer for anything under four.

TRANSCRIPT:
[paste]
```
