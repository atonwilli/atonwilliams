# Objections, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are building a complete objection-handling system for my team. Read CONTEXT, then THE METHOD, then follow BUILD. Ask me up to five questions first about anything blank or unclear. Use only the product facts. Never disparage a competitor. Never recommend pressure.

CONTEXT
- What we sell and the verified product facts (does, costs, included, NOT included): [ ]
- Claims we can make: [ ]   Claims we never make: [ ]
- Medium (retail or events, phone, meetings, or a mix): [ ]
- Who the customer is: [ ]
- The ten objections we hear most, in the customer's words: [ ]
- Competitors or alternatives customers mention: [ ]
- Our commitment terms (contract, cancellation, refund), stated exactly: [ ]
- Words we use: [ ]   Words we never use: [ ]

THE METHOD
The five-second test: is there a specific noun in the objection? No noun ("I am good," "not today") is a REFLEX and gets a three-word nod plus a question, never a fact. A noun ("we are under contract," "it failed last time") is a REASON and gets the three-line answer: validate ("I hear you"), normalize ("other people in your spot felt the same way"), pivot ("here is what we found for them"), then a value rebuild against the reason they named, on one of three angles: COST (dollars and time), QUALITY (how well it performs), VALUE (what is included they did not expect). Stop rules: a reason we cannot answer honestly ends the conversation; two clean nos means done; anyone on a fixed income, in hardship, or confused gets slowed down; if asked to stop or leave, we do it and log it; the rep never decides for the customer.

BUILD
1. THE DIAGNOSTIC in our words, with ten of our own objections classified as examples.
2. THE BANK: forty objections our customers raise (start from the ten in CONTEXT, then the thirty most likely for our product and medium). For each: the line as a customer says it, REFLEX or REASON, the angle if reason, the answer in our words, one rebuild line from our facts, and a medium note.
3. TWELVE REBUILD LINES for our product, four per angle.
4. THE STOP RULES rewritten for our business, including our exact commitment terms.
5. A TWO-WEEK DRILL SCHEDULE, fifteen minutes a day in pairs, using our bank.
6. TWO PROMPTS I can paste later with our facts inside: a sparring partner that plays our customer, and an answer grader for transcripts.
7. A ONE-PAGE CARD: the five-second test, the nod, the three lines, the three angles, the stop rules.

Rules: plain language, no jargon, no dashes. At least five objections in the bank must be marked STOP with the reason. Mark any assumed fact as [CHECK].
```

## 1. The five-second test

```
Build an objection bank for the product below. I want forty objections a real customer would raise, sorted into REFLEX (no specific noun, could be said to anyone) and REASON (contains a specific concern), and for reasons, tagged COST, QUALITY, or VALUE.

For each objection give: the line as a customer would say it, the classification, the answer (three-word nod plus a question for reflexes; validate, normalize, pivot for reasons), and one rebuild line that uses only the product facts provided.

Rules: use only the facts below, never invent capabilities, never disparage competitors, include at least five objections that should END the conversation and say so.

Product facts: [paste]
Medium: [retail / phone / meeting]
Customer type: [describe]
```

## Prompt B. Sparring partner

```
You are a customer raising objections so a rep can practice. Medium: [ ]. Product category: [ ]. Your real reason for hesitating, which you will only reveal if the rep handles a reflex well and asks a genuine question: [ ].

Start with a reflex. If the rep argues with it, escalate. If the rep nods and asks a question, answer it and raise your real reason. If the rep validates, normalizes, and pivots, soften. If they skip a step, repeat the objection in different words.

Stay in character until STOP. Then give: which objections were reflexes and which were reasons, whether the rep diagnosed each correctly, and the single line to change.
```

## Prompt C. Answer grader

```
Grade these objection answers. For each: was the objection a reflex or a reason, did the rep treat it correctly, did the answer contain the right structure (three-word nod plus question, or validate, normalize, pivot, rebuild), did the rebuild match the angle (cost, quality, value), and did the rep ever argue, pressure, or invent a claim. Score each out of five and give the rewritten answer for anything under four.

TRANSCRIPT:
[paste]
```
