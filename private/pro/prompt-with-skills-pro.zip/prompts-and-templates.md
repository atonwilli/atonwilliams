# Prompt With Skills, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## 1. Folder layout

```
/skills
  INDEX.md
  meeting-notes-to-actions.md
  weekly-report.md
  job-post.md
  sop-writer.md
  sales-email.md
  linkedin-post.md
  customer-reply.md
  decision-memo.md
  content-repurpose.md
  objection-drill.md
```

## 2. The index

```
# SKILLS INDEX
Say "run <name>" and paste the input. Each skill states its input, its output, and its rules.

meeting-notes-to-actions   Raw notes in, owners and dates out.
weekly-report              Numbers in, one-page report out.
job-post                   Role facts in, a post that filters out.
sop-writer                 A walkthrough in, a numbered SOP out.
sales-email                A conversation summary in, a five-line email out.
linkedin-post              One idea in, a post in our voice out.
customer-reply             A customer message in, a reply out.
decision-memo              A question in, a one-page memo out.
content-repurpose          One piece in, five formats out.
objection-drill            A product in, a drill session out.
```

## 3. The ten skills

```
# SKILL: meeting-notes-to-actions
INPUT: raw meeting notes or a transcript.
OUTPUT: a decisions list and an actions list with owners and dates.
RULES: read the brain file first. Never invent an owner; write "unassigned." Never invent a date; write "no date." One line per item.

STEPS
1. Read the notes once. List every decision that was made, as a one-line statement in past tense. ("We will..." becomes "Decided: ...")
2. List every action. Each needs an owner and a date. If either is missing, mark it.
3. List open questions that were raised and not answered.
4. Flag anything that conflicts with DECISIONS.md.

FORMAT
DECISIONS
- Decided: ...
ACTIONS
- [Owner] [Date] Action
- [unassigned] [no date] Action
OPEN
- ...
CONFLICTS
- ...
```

## skills/weekly-report.md

```
# SKILL: weekly-report
INPUT: this week's numbers and last week's numbers, plus up to five notes from the leader.
OUTPUT: a one-page report in our voice.
RULES: never add a number that is not in the input. Show the change, not just the value. No adjectives about the numbers ("great," "disappointing"); the reader judges.

STEPS
1. Table the leading numbers: this week, last week, change.
2. One paragraph: what moved and the most likely reason, using only the leader's notes.
3. One paragraph: the one thing next week, from the notes.
4. Flags: any number that moved more than 20 percent either way.

FORMAT
WEEK OF [date]
[table]
WHAT MOVED
...
NEXT WEEK
...
FLAGS
...
```

## skills/job-post.md

```
# SKILL: job-post
INPUT: role title, what a day looks like, hours, pay structure, the hard truths, the first step you want applicants to take.
OUTPUT: a job post that makes the wrong people close the tab and the right people feel something.
RULES: the hard truth goes in the second sentence. Describe a day, not a personality. No "self-starter," "rockstar," "ninja," "hungry." The first step is a small test (a specific subject line, a one-question answer, a short video). Under 250 words.

STEPS
1. Sentence one: what the role is, plainly.
2. Sentence two: the hardest true thing about it.
3. A paragraph: a day in the role. Where they are, who they talk to, what a good afternoon looks like.
4. A short list: what they get (pay structure, training, the path).
5. Who this is not for, in two lines.
6. The first step, with the specific instruction.
```

## skills/sop-writer.md

```
# SKILL: sop-writer
INPUT: a walkthrough of a task (transcript, voice note, or bullet points) from the person who does it best.
OUTPUT: a numbered SOP a competent stranger could follow on day one.
RULES: one action per step. Start each step with a verb. Include what "done" looks like at the end. Include the one place people usually get stuck, as a note. Name an owner.

FORMAT
# SOP: [name]
Owner: [name]. Last updated: [date]. Time: about [n] minutes.
WHEN: [the trigger that starts this]
STEPS
1. ...
2. ...
DONE WHEN: ...
WATCH OUT: [the one step people get wrong]
```

## skills/sales-email.md

```
# SKILL: sales-email
INPUT: a summary of the conversation (what the buyer said the decision depends on, what was agreed, next step, date).
OUTPUT: a follow-up email in five lines.
RULES: line one restates what THEY said, not what we pitched. No attachments unless they asked. No "just checking in." One question at the end, answerable in one word.

FORMAT
Subject: [what we agreed], [date]
Line 1: You said the decision depends on [their words].
Line 2: Here is what we agreed: ...
Line 3: What happens next: ...
Line 4: By when: ...
Line 5: One question: ...?
```

## skills/linkedin-post.md

```
# SKILL: linkedin-post
INPUT: one idea, one real example (anonymized), and the lesson.
OUTPUT: a post in our voice, under 180 words.
RULES: first line is the hook and stands alone. One idea only. The example is specific and generic (no client names, no real numbers unless verified). End with one line the reader can use tomorrow. No hashtags. No emoji. No "agree?" No dashes.

STEPS
1. Hook: the lesson as a claim, under twelve words.
2. The example, three to five short lines.
3. The turn: what most people get wrong.
4. The line to use tomorrow.
5. Check against VOICE.md. Remove any banned word.
```

## skills/customer-reply.md

```
# SKILL: customer-reply
INPUT: a customer message and the relevant facts (order, appointment, policy).
OUTPUT: a reply.
RULES: answer the question in the first sentence. Apologize once if we were wrong, never if we were not. Never promise something not in the facts. Give one next step with a time. Sign with a first name.

STEPS
1. What is the customer actually asking? One line.
2. Answer it.
3. If there is a problem: what we will do, by when.
4. One line to close.
Check length: under 120 words unless the facts require more.
```

## skills/decision-memo.md

```
# SKILL: decision-memo
INPUT: a question we need to decide, the options, what we know, what we do not.
OUTPUT: a one-page memo the owner can decide from in five minutes.
RULES: recommend one option. State the strongest case against it. Mark every unknown. Never bury the recommendation.

FORMAT
DECISION NEEDED: [one line]
RECOMMENDATION: [one line]
WHY: three bullets
THE CASE AGAINST: two bullets
WHAT WE DO NOT KNOW: bullets
IF YES, NEXT STEP: owner, date
IF NO, NEXT STEP: owner, date
```

## skills/content-repurpose.md

```
# SKILL: content-repurpose
INPUT: one finished piece (a note, a guide section, a transcript).
OUTPUT: five formats: a LinkedIn post, three short video hooks, a newsletter paragraph, a one-line quote card, and a community post with a question.
RULES: every format keeps the same one idea. No new claims. Follow VOICE.md. Mark any line that needs a real number or a real example as [NEEDS EXAMPLE].
```

## skills/objection-drill.md

```
# SKILL: objection-drill
INPUT: product facts, medium, and the rep's weakest objection type (reflex or reason).
OUTPUT: a fifteen-minute drill session: ten objections in order of difficulty, the classification of each, the model answer, and what the coach listens for.
RULES: use only the product facts. At least two objections should end the conversation and be marked "stop." No pressure tactics.
```

## 4. The skill template

```
# SKILL: [name, lowercase with hyphens]
INPUT: [exactly what to paste]
OUTPUT: [exactly what comes back]
RULES: [three to six hard rules, including at least one "never"]

STEPS
1. ...
FORMAT
...
```

## 5. The skill-writing checklist

```
I keep doing this task by hand: [describe the task and paste the last prompt you typed for it]. Turn it into a skill file using this exact shape: name, INPUT, OUTPUT, RULES (at least one "never"), STEPS, FORMAT. Then give me three test inputs of different difficulty and what the output should look like for each. Keep the whole skill under 250 words.
```

## Prompt B. Skill tester

```
Run the skill below against the three inputs. For each output, check: did it follow every RULE, did it produce the FORMAT exactly, did it invent anything not in the input. Report pass or fail per rule, then rewrite the weakest rule to be more specific.

SKILL:
[paste]
INPUT 1:
[paste]
INPUT 2:
[paste]
INPUT 3:
[paste]
```
