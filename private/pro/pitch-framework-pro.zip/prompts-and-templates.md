# The Pitch Framework, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are building a complete pitch for my team using a five-beat framework. Read CONTEXT, then THE METHOD, then follow BUILD. Before building, ask me up to five questions about anything blank or unclear in CONTEXT. Only promise what the product facts support.

CONTEXT
- What we sell, in plain words: [ ]
- Verified product facts (what it does, what it costs, what is included, what is NOT included): [ ]
- Claims we can make: [ ]   Claims we never make: [ ]
- The customer problems it actually solves, in the customer's words if possible: [ ]
- Medium (retail or events, phone, meetings, or a mix): [ ]
- Who the customer is and what they are afraid of: [ ]
- Our name and how reps introduce themselves: [ ]
- Words we use: [ ]   Words we never use: [ ]

THE METHOD
Five beats in order. OPEN: earn the next fifteen seconds; under ten words, ends in a question, never a statement about us. STORY: why we are here and why it matters to them, two sentences, ends in a discovery question (what are they using now, what do they wish worked better, what happens when it fails). SHOW: only after one real detail; show exactly one thing tied to what they said, then check "does that address what you described?" ASK: a choice between two real options, never yes or no; use a tie-down first (a small question that gets a small yes). LOCK: say what happens next, when, and who to call, so the yes survives the walk to the car. Retail opens are physical first (face them, then speak). Phone opens are name, company, one reason, one permission question in under eight seconds. Meeting opens are a question about them before any slide. Ready signals: a second price question, timing questions, "what happens if" about the future, repeating our line back, bringing in the decider, shrinking objections, asking what they would need to do, leaning in. The three asks: alternate choice, assumptive next step (only after three yeses), direct (only after three yeses).

BUILD
1. THE PITCH: all five beats for our medium, one primary line each, in our words, using our product facts. If we use more than one medium, build each.
2. FORTY-FIVE LINES: three variants per beat per medium.
3. THREE WORKED CONVERSATIONS with our product: an easy customer, a realistic one, a hard one, each running all five beats with the customer's replies.
4. THE READY SIGNALS as they would sound with our customers, and the three asks in our words.
5. A SEVEN-DAY DRILL PLAN, fifteen minutes a day in pairs, one beat per day, full runs on day seven.
6. THE SCORECARD, ten points, one line per item.
7. TWO PROMPTS I can paste later with our facts inside: a pitch critic that grades a transcript, and an interruption trainer that plays our customer.
8. A ONE-PAGE VERSION for the wall: the five beats, one line each.

Rules: plain language, no jargon, no hype, no dashes. Every claim must trace to the product facts. Mark anything you had to assume as [CHECK].
```

## 1. The five beats, in depth

```
[ ] Open ended in a question, under ten words                       __ / 1
[ ] Story gave a reason and ended in a discovery question           __ / 1
[ ] Got one real detail before presenting                           __ / 2
[ ] Showed one thing tied to that detail                            __ / 2
[ ] Checked: "does that address what you described?"                __ / 1
[ ] Used at least one tie-down                                      __ / 1
[ ] Asked with an alternate choice                                  __ / 1
[ ] Locked: next step, time, who to call                            __ / 1
                                                          TOTAL     __ / 10
```

## 7. The four prompts

```
Build a five-beat pitch (Open, Story, Show, Ask, Lock) for the product below in the medium below.

Rules:
- The open is under ten words and ends in a question.
- The story is two sentences and ends in a discovery question.
- The show presents exactly ONE thing, tied to a stated customer problem, and ends with "Does that address what you described?"
- The ask is a choice between two real options.
- The lock states the next step, the time, and who to call.
- Use only the product facts I give you. If a claim is not in the facts, do not make it.
- Plain language. No industry jargon. No hype.

Then give me two alternate lines for each beat.

Medium: [retail or event / phone / meeting]
Product facts: [paste verified facts only]
The customer problems this product solves: [list]
```

## Prompt B. Pitch critic

```
Grade this pitch against the five beats. For each beat: present or missing, one sentence on why, and a rewritten line if it is weak. Then give the total out of ten using this card: open ends in a question (1), story ends in discovery (1), one real detail before presenting (2), one thing shown tied to it (2), the check question (1), a tie-down (1), an alternate-choice ask (1), a lock with next step, time, and who to call (1).

Do not praise. Do not soften. Quote the exact words that lose the customer.

PITCH:
[paste transcript or script]
```

## Prompt C. Interruption trainer

```
You are a customer in a [medium] conversation about [product category]. Your job is to interrupt the rep at realistic moments so they learn to hold the five-beat structure in their own words.

Interrupt at least four times: once during the open with a reflex ("just looking" or "not interested"), once during the story with an unrelated question, once during the show with a price question, and once at the ask with "let me think about it."

Stay in character until STOP. After STOP, list the beats the rep held and the beat where they lost the structure, with the line they said when they lost it.

Begin by responding to the rep's opening line.
```

## Prompt D. Medium translator

```
Translate this pitch from [source medium] to [target medium]. Keep the five beats and the meaning. Change the length, the rhythm, and the physical cues to fit the target:

- Retail and events: short lines, present tense, one physical instruction per beat (where to stand, when to hand something over).
- Phone: name, company, reason, permission in the open; shorter shows; a spoken confirmation in the lock.
- Meetings: a question before any slide; the show is one screen; the ask names an owner and a date.

PITCH:
[paste]
```
