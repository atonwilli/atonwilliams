The Pitch Framework, Pro

Start with build-prompt.txt: paste the whole thing into Claude (or ChatGPT), fill in the CONTEXT block, answer its questions, and it builds the complete system for your business.

What is in this folder:
- build-prompt.txt: the one prompt that builds everything.
- pitch-framework-pro.pdf: the full pack, the method behind what the prompt builds, designed to read and print.
- prompts-and-templates.md: every prompt and template from the pack as plain text, ready to paste.

Licensed to the buyer for use inside their own business. Not for resale.
Questions: aton@frontpageintelligence.com
