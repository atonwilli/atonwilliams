# Prevent AI Drift, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are building a drift-prevention system for the AI work in my business. Read CONTEXT, then THE METHOD, then follow BUILD. Ask me up to five questions first if CONTEXT is thin.

CONTEXT
- My brain file (paste it, or describe our voice rules, banned words, offers and prices, and private matters): [ ]
- Our decisions log, or the five decisions people keep reopening: [ ]
- The kinds of output we produce most (customer emails, posts, reports, SOPs, code, other): [ ]
- Three recent outputs I was happy with (paste or describe): [ ]
- Three recent outputs that felt off, and what was off: [ ]
- The tools and models we use: [ ]
- How long our typical AI session runs and how many pieces of work it produces: [ ]

THE METHOD
Five kinds of drift: VOICE (longer sentences, adjectives, banned words return), FACTS (numbers rounded, then estimated, then invented; unverified capabilities), SCOPE ("I also" in a report; a post becomes a campaign), FORMAT (a skill's output shape changes), DECISIONS (a settled decision gets reopened because the session forgot it). A GUARDRAILS.md sits next to the brain file with checks to run before producing and before returning anything. A weekly ten-minute audit pulls five outputs, runs a drift detector on each, and any break that appears twice becomes a guardrail line. A regression set is ten small tasks with a known expected shape, run whenever the tool, model, or brain file changes, compared against a saved baseline. Reset a session after ten pieces of work, two failed regression tasks, one self-contradiction, or the same correction twice; carry over only a 150-word state summary.

BUILD
1. GUARDRAILS.md for my business, with our actual banned words, our offers and prices as the fact source, our private matters, and our reopened decisions.
2. THE WEEKLY AUDIT checklist, ten minutes, with the exact steps and where to record results.
3. THE REGRESSION SET: ten tasks for our kinds of output, each with the expected shape and the specific facts the answer must contain. Then produce the BASELINE by answering all ten yourself using only CONTEXT.
4. RESET RULES and the state-summary template.
5. THREE PROMPTS with our rules inside them: a drift detector, a style diff against our approved samples, and a fact check against our offers.
6. FIRST AUDIT: run the drift detector on the three outputs that felt off, name the drift type for each, and give the corrected version.

Rules: plain language, no dashes, nothing invented about my business beyond CONTEXT (mark assumptions [CHECK]).
```

## 1. The five kinds of drift

```
# GUARDRAILS
Read after BRAIN.md. These are checks, not suggestions.

BEFORE PRODUCING ANYTHING
- Which skill or format applies? Name it. If none, use plain prose under 200 words.
- Which decisions in DECISIONS.md touch this? List them.

BEFORE RETURNING ANYTHING
- Banned words present? [list] If yes, remove and say so.
- Any number, quote, or capability not in BRAIN.md section 3? Mark [UNVERIFIED].
- Did the scope grow past the request? If yes, cut it and list what was cut.
- Does the output match the FORMAT of its skill? If no, reformat.
- Does anything contradict DECISIONS.md? If yes, stop and say which line.

WHEN IN DOUBT
- Ask one question instead of guessing.
- Shorter is safer.
```

## 3. The weekly drift audit

```
[ ] Pull five outputs from this week (one customer-facing, one internal report, one post, one SOP or skill output, one anything).
[ ] Run Prompt A (drift detector) on each. Count the breaks.
[ ] Any break that appears twice becomes a line in GUARDRAILS.md.
[ ] Run the regression set (section 4) on the tool you use most. Note any task whose shape changed.
[ ] Check DECISIONS.md against this week's recommendations. Any reopened decision? Log it and add the decision to the brain file's section 6.
[ ] Update the "last audited" date at the top of GUARDRAILS.md.
```

## 4. The regression set

```
1. "Describe what we sell in two sentences."           Expect: exact offer names and prices from section 3.
2. "Write a two-line customer reply to a late arrival." Expect: one apology, one next step with a time, under 40 words.
3. "List our banned words."                             Expect: the exact list from section 4.
4. "What did we decide about [a logged decision]?"     Expect: the decision, the date, no re-argument.
5. "Write a LinkedIn hook about coaching."             Expect: under 12 words, no dashes, no emoji.
6. "Turn these three bullets into an SOP."             Expect: numbered verbs, owner line, DONE WHEN line.
7. "Give me our average install time."                 Expect: the verified figure, or "unknown."
8. "Summarize this week's numbers." (with three given)  Expect: a table and three sentences, no adjectives.
9. "Add a feature to our service plan."                Expect: a refusal to invent, and a question.
10. "Rewrite this paragraph in our voice." (a hype paragraph)  Expect: short sentences, specifics, no hype words.
```

## 5. Reset rules

```
Compare the output below against BRAIN.md and GUARDRAILS.md. Report every break in five categories: VOICE (banned words, sentence length, tone), FACTS (numbers, quotes, capabilities not in section 3), SCOPE (anything beyond the request), FORMAT (does it match the skill's format), DECISIONS (contradicts DECISIONS.md). For each break: quote the line, name the rule, give the corrected line. End with a count per category and a one-line verdict: clean, minor drift, or reset recommended.

BRAIN FILE AND GUARDRAILS:
[paste]
THE REQUEST THAT PRODUCED THIS OUTPUT:
[paste]
OUTPUT:
[paste]
```

## Prompt B. Style diff

```
Here are two pieces of writing: one from our baseline (approved) and one from this week. Ignore the topic. Compare only style: average sentence length, adjectives per sentence, banned words, punctuation habits, hedging phrases, and opening patterns. Show the numbers side by side, then name the three habits that changed and give a one-line rule for GUARDRAILS.md that would catch each.

BASELINE:
[paste]
THIS WEEK:
[paste]
```

## Prompt C. Fact check against the brain file

```
Check every factual claim in the text below against BRAIN.md section 3 (what we sell, claims we can make, claims we never make). For each claim: found (quote the source line), not found (mark [UNVERIFIED]), or contradicted (quote both). Do not rewrite the text. Just the list, then a count.

BRAIN FILE SECTION 3:
[paste]
TEXT:
[paste]
```
