The Operators Pro Library by Aton Williams

Ten Pro packs, one folder each: the PDF and the prompts as plain text.
Licensed to the buyer for use inside their own business. Not for resale.
