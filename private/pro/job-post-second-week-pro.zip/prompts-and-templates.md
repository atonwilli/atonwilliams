# The Hiring System, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are building a hiring system for one role. Read CONTEXT, then THE METHOD, then follow BUILD. Ask me up to five questions first. Use only my facts. No personality words in the post (self-starter, rockstar, ninja, hungry). No earnings claims.

CONTEXT
- The role, in one sentence, and where the person works: [ ]
- Hours, pay structure, and the hardest true things about the role: [ ]
- What a good day looks like, who they talk to, what the debrief after a shift sounds like: [ ]
- Who leads them and how much time that leader has: [ ]
- Systems and access they need: [ ]
- Our channels for applicants and how fast we reply today: [ ]
- Our voice rules and banned words: [ ]

THE METHOD
The post is the first interview: the hard part in the second sentence, a day not a personality, a small test as the first step, and it should turn the wrong people away. Hire for hunger, train for skill: hunger is a specific want this seat can get them plus evidence they have done hard things to get closer to it; the question is "tell me about something you wanted badly enough to be bad at it for a while." Speed filters for interest: reply fast, book the call the same day, remind before it. The second round filters instead of sells. Nobody quits in week one; they decide in week two, so the structure goes there: a daily named check-in, a same-day debrief after the first bad shift, a visible early win, and the day-ten conversation (how is it going, what surprised you, what do you need). Measure week-two activity, not week-one attendance.

BUILD
1. THE POST, under 250 words, in the structure above, in our voice.
2. THE SMALL TEST: the exact first step and how to score it.
3. THE SCREEN: five first-call questions including the hunger question, with what a hungry answer sounds like and what a resume answer sounds like.
4. THE PIPELINE: reply-speed rule, the booking message, the reminder message, the no-show rule, and who owns each.
5. THE SECOND ROUND: a twenty-minute script that filters: three questions, one live exercise from the role, the close that names the gate they must pass in training.
6. DAYS ONE TO TEN: day by day, every item with an owner, the first win, the same-day debrief, the daily check-in, the day-ten conversation word for word.
7. THE NUMBER: the week-two activity number for this role and the level that predicts a ninety-day stay.
8. QUIZ MODE: twelve applicant answers to the hunger question; for each, hungry or not, and why.

Rules: plain language, no dashes, no earnings claims, mark assumptions [CHECK].
```

## 1. The post that filters

```
POST CRITIC. Grade this job post: is the hard part in the second sentence, does it describe a day, are there personality words, is there a small test as the first step, would the wrong people close the tab? Rewrite the weakest part. POST: [paste]
```
