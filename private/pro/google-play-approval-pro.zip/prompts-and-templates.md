# Google Play Approval, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the readiness prompt

```
You are scoring an Android app for Google Play review readiness. Read CONTEXT, then THE CHECKLIST, then produce THE SCORECARD. Use only what I tell you; mark anything you cannot tell as UNKNOWN with what to check. Explain what each failing item means and why the policy exists. Do not give implementation steps.

CONTEXT
- What the app does and for whom: [ ]
- What people buy inside it, and whether it is digital or physical or an outside service: [ ]
- How people pay today: [ ]
- Accounts: create, delete in the app, web deletion link declared: [ ]
- Data collected and shared, and why: [ ]
- Permissions requested: [ ]
- User content: post, message, share, profiles: [ ]
- Audience: could children use it; ads present: [ ]
- Testing: has a closed test run with real testers; is the developer account new: [ ]
- Target API level, crashes known, placeholder screens, links: [ ]
- Screenshots: from which build; any paid features shown: [ ]
- Review credentials in the console: [ ]

THE CHECKLIST (forty items, grouped)
Money: digital goods through Play Billing; physical goods and outside services may use other payment; subscription terms and price shown before purchase; restore and manage subscriptions reachable; no misleading free trials.
Accounts and data: account deletion inside the app; a web link to request deletion declared in the console; the data safety form matches what the app collects and shares; privacy policy linked in the console and in the app; data collected only for stated purposes.
Permissions: every sensitive permission has a visible reason at the moment of need; declaration forms filed for restricted permissions; no requesting permissions the core function does not need.
Completeness and testing: closed testing completed if the account requires it; review credentials in app access and working; no crashes on launch or main paths; no coming soon or placeholder screens; every link resolves; target API level current; app does what the listing says.
Listing: screenshots from the current build; features shown exist; paid features marked; no misleading claims; content rating questionnaire answered for the shipped app; target audience declared correctly; ads declared if present.
Content and users: report, block, moderation, and contact if there is user content; content within the rating; families policy met if children could be an audience; no deceptive behavior or hidden functionality.

THE SCORECARD
For every item: PASS, FAIL, or UNKNOWN, with one line. Then: the items most likely to return the app, in order; what each policy protects; the three declarations to get right first. End with a readiness score out of forty.
```

## 1. The forms are the review

```
RETURN REPLY. Here is the Play policy notice. Write my appeal or resubmission note in under 120 words: the policy named, what I changed in the app and in the declarations, and where a reviewer can verify it. NOTICE: [paste]  WHAT I CHANGED: [paste]
```
