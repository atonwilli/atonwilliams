# The Sales Debrief, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are building a complete sales debrief system for my team. Read CONTEXT, then read THE METHOD, then follow BUILD exactly. Before building, ask me up to five questions about anything in CONTEXT that is blank or unclear. Do not build until I answer.

CONTEXT
- My business and what we sell: [one or two sentences]
- How we sell (retail or events, phone, meetings, or a mix): [ ]
- Team: [number of reps, number of leaders, whether leaders run shifts]
- A typical shift or block of calls looks like: [ ]
- The three things reps most often get wrong in a conversation: [ ]
- Words and phrases we use: [ ]   Words we never use: [ ]
- Where we keep shared notes (a doc, a CRM, a chat): [ ]
- Start date for the rollout: [ ]

THE METHOD
A debrief is ten minutes, after every shift, one rep, one conversation. Minute 0 to 1: pick the conversation the rep is still thinking about. Minutes 1 to 4: three questions in order: what did the customer say they wanted to change (their words), what did you present and how did it connect, what do we still not know. Minutes 4 to 6: name exactly one skill in the shape "the moment was X, the change is Y." Minutes 6 to 9: run the moment again, leader plays the customer, starting two lines before the break. Minutes 9 to 10: write two lines, SKILL and LISTEN FOR, and read them aloud. Coach only what was observed. Never invent the customer's motive. Never name a second skill. The log is one shared doc per rep: DATE, CONVERSATION, SKILL, LISTEN FOR. The leader fills a weekly sheet per rep: debriefs run, skills named, the repeated skill, second passes run, next week's one thing. A skill repeated three times in a week is a training gap: build a group drill. Rollout: days 1 to 3 leader only, days 4 to 10 every rep every shift, days 11 to 20 second-line leaders run it and the top leader audits, days 21 to 30 weekly group drills on the most repeated skill. Measure debriefs per rep per week and second passes per debrief, not sales, for thirty days.

BUILD
Produce these, in this order, each as its own clearly titled section, written in our words from CONTEXT:
1. THE SOP: the ten-minute debrief, step by step with timing, using our product and our medium in every example.
2. THE LOG TEMPLATE: ready to paste into the place we keep notes, with one filled example from our business.
3. THE WEEKLY SHEET: the leader's review sheet with the two reading rules.
4. FIFTEEN SCRIPTS for our medium (if we use more than one medium, split them): each with the coach's opening question, what to listen for, and the drill, built around the three mistakes in CONTEXT.
5. FOUR PROMPTS I can paste later, with our product facts already inside them: (a) notes to drill, (b) weekly log to coaching plan, (c) role-play customer for our medium, (d) leader self-audit.
6. THE THIRTY-DAY ROLLOUT with real dates from our start date, who does what each phase, and the two numbers to watch.
7. THE SCORECARD for grading a leader's debrief, five items, two points each.
8. A ONE-PAGE VERSION I can print and hand to every leader.

Rules: plain language, short sentences, no jargon, no hype, no dashes. Never invent numbers or customer quotes. If something depends on a fact I did not give you, ask, or mark it [FILL IN].
```

## 1. The ten-minute debrief SOP

```
DATE            2026-09-08, evening shift
CONVERSATION    Woman with two kids, asked about the price twice
SKILL           Ask what "better" means before presenting features
LISTEN FOR      A discovery question before the first feature is mentioned
```

## The weekly review sheet (leader)

```
REP                     ____________
DEBRIEFS THIS WEEK      __ of __ shifts
SKILLS NAMED            1. ____________  2. ____________  3. ____________
REPEATED SKILL          ____________   (the same skill named twice or more is the real coaching point)
SECOND PASS RUN         __ of __ debriefs   (if this is low, the leader is naming and not drilling)
NEXT WEEK'S ONE THING   ____________
```

## 3. Fifteen debrief scripts by medium

```
You are helping a sales leader prepare a ten-minute coaching debrief.

Use only the information in NOTES. Do not invent customer quotes, product capabilities, motives, or reasons a sale was lost. If the notes are incomplete, say what is missing and give me the one question to ask the rep before choosing a drill.

Produce, in this order:

1. THE CUSTOMER'S PROBLEM, in their words if a quote exists. If not, label it "summary" or "unknown."
2. THE CONNECTION: how the rep tied the presentation to that problem, with evidence from the notes. If there is no evidence, say so.
3. THE MOMENT: the single point in the conversation where it broke, in one sentence shaped "the moment was X."
4. ONE SKILL, in one sentence shaped "the change is Y." Exactly one.
5. THE SECOND PASS: a role-play that starts two lines before the moment. Give the customer's opening line, what the rep should practice, and what I should listen for. Keep it under 120 words.
6. THE TWO LINES for the log: SKILL and LISTEN FOR.
7. ONE QUESTION for the next debrief.

Medium: [retail / phone / meeting]
Keep everything direct and specific. Respect a customer's decision to decline. Never recommend pressure, misleading claims, or guessing at product benefits.

NOTES:
[paste anonymized notes or transcript]
```

## Prompt B. Weekly log to coaching plan

```
You are helping a sales leader turn a week of two-line debrief logs into one coaching plan per rep.

For each rep in LOGS:
1. List the skills named this week.
2. Identify the repeated skill, if any. A skill named two or more times is the priority. If nothing repeats, pick the one with the highest impact on the customer conversation and say why in one sentence.
3. Write next week's ONE THING for this rep in one sentence.
4. Design one group drill if the same skill appears across two or more reps. Give it a name, a fifteen-minute structure, and what the leader listens for.
5. Flag any rep whose log has fewer than three debriefs this week. That is a leader gap, not a rep gap.

Do not invent conversations that are not in the logs. Do not rank reps against each other. Output one short block per rep, then the group drill, then the flags.

LOGS:
[paste the week's two-line logs, one block per rep]
```

## Prompt C. Role-play customer by medium

```
You are playing a customer so a sales rep can practice one specific skill. Stay in character until I write STOP.

Medium: [retail or event / phone / meeting]
Product category: [describe generically, for example "a monthly service plan"]
Your situation: [one sentence, for example "your current provider keeps failing at the worst moments and nobody answers when you call"]
The skill the rep is practicing: [one sentence]
Your difficulty: [easy / realistic / hard]

Rules:
- Answer like a real person in this medium. Short answers on the phone, distracted answers at a kiosk, guarded answers in a meeting.
- Only reveal your real reason if the rep asks a genuine discovery question. If they present first, get vaguer.
- If the rep uses the skill well, warm up a little. If they skip it, raise a reflex objection.
- Never coach mid-scene. After STOP, give three lines: what the rep did well, the one moment to change, and the line you wished they had said.

Start the scene with your opening line now.
```

## Prompt D. Leader self-audit

```
I am a sales leader. Below are my last five debrief logs. Audit ME, not the reps.

Check:
1. Did I name exactly one skill each time? Flag entries with two or more.
2. Is the skill observable behavior ("asked before presenting") or a vague trait ("be more confident")? Rewrite any vague ones as behavior.
3. Did I run a second pass? If the log does not mention it, assume I did not.
4. Am I naming the same skill for every rep? That usually means I am coaching my favorite topic, not what I observed.
5. Is my LISTEN FOR line something I could actually hear in the next conversation?

Give me a score out of ten, the single habit to fix this week, and a rewritten version of my weakest entry.

LOGS:
[paste five entries]
```

## 5. The thirty-day rollout

```
[ ] Picked one conversation in under a minute                        __ / 2
[ ] Asked the three questions in order, did not skip to advice       __ / 2
[ ] Named exactly one skill, as observable behavior                  __ / 2
[ ] Ran the second pass, leader playing the customer                 __ / 2
[ ] Wrote and read the two lines before the rep left                 __ / 2
                                                          TOTAL      __ / 10
```
