# Sales Terms, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are building a sales vocabulary training kit for my team. Read CONTEXT, then THE TERMS, then follow BUILD. Ask me up to five questions first if CONTEXT is thin. Use only my numbers; where I did not give one, use a clearly marked example figure.

CONTEXT
- What we sell, price, and how reps are paid (commission structure, any clawback window, any override): [ ]
- Medium and what a shift or block looks like: [ ]
- Our real numbers if I have them (rough CAC, average customer lifetime, churn, close rate, show rate): [ ]
- What counts as a set, a conversation, and activity for us: [ ]
- Our ramp period and promotion path, if written: [ ]
- Our voice rules and banned words: [ ]
- Where new reps are trained and how long the first week is: [ ]

THE TERMS
Forty terms in four groups. Money: CAC, LTV, LTV to CAC, gross versus net, clawback, churn, margin, payback period, retention, pipeline. Conversation: CTA, discovery, tie-down, alternate close, assumptive close, trial close, reflex objection, reason objection, rebuttal, the last few feet, lock, value rebuild, talk ratio, pattern interrupt, qualifying. Floor: set, show rate, close rate, activity, shift, territory or venue, ramp, debrief, role-play, scoreboard. Leadership: leading versus lagging indicators, override, promotion path, gate, standard. Each term is taught in four parts: what it is, the mistake new reps make with it, the drill, and a one-line for the morning meeting.

BUILD
1. THE FORTY TERMS, each in four parts, with our product, our pay structure, and our numbers in the examples.
2. THE ONBOARDING WEEK: five days, fifteen minutes a day, which terms each day, the exercise, and the pass mark for the quiz on day five.
3. TEN MORNING MEETING CARDS: term, a thirty-second story from our kind of floor, the one-line, and the explain-it-back question.
4. THE QUIZ: forty situational questions set in our business, one per term, with a one-sentence model answer each and a passing score.
5. TWO PROMPTS I can paste later: a quiz generator loaded with our facts, and an explain-it-back grader.
6. A ONE-PAGE GLOSSARY for the wall: forty terms, one line each.

Rules: plain language, no jargon beyond the terms themselves, no dashes, no earnings claims, every number either mine or marked as an example.
```

## 1. Money terms

```
Using the forty sales terms below and the product facts I give you, write a forty-question quiz where every question is set in a realistic situation with our product. Each question has a one-sentence model answer. Group them money, conversation, floor, leadership. Use only the product facts. Mark the passing score at 32.

TERMS:
[paste sections 1 to 4]
PRODUCT FACTS:
[paste]
```

## Prompt B. Explain-it-back grader

```
A rep explained these terms in their own words. For each, grade: correct, partly correct, or wrong, quote the part that is wrong, and give the one sentence I should say to fix it. Do not grade on vocabulary. Grade on whether they could act on the term tomorrow.

TERMS AND THEIR EXPLANATIONS:
[paste]
```
