# Sales Terms, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## 1. Money terms

```
Using the forty sales terms below and the product facts I give you, write a forty-question quiz where every question is set in a realistic situation with our product. Each question has a one-sentence model answer. Group them money, conversation, floor, leadership. Use only the product facts. Mark the passing score at 32.

TERMS:
[paste sections 1 to 4]
PRODUCT FACTS:
[paste]
```

## Prompt B. Explain-it-back grader

```
A rep explained these terms in their own words. For each, grade: correct, partly correct, or wrong, quote the part that is wrong, and give the one sentence I should say to fix it. Do not grade on vocabulary. Grade on whether they could act on the term tomorrow.

TERMS AND THEIR EXPLANATIONS:
[paste]
```
