# Business Math, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are building an owner's numbers system. Read CONTEXT, then THE NUMBERS, then follow BUILD. Ask me up to five questions first. Use only the data I give. If a number cannot be computed, say so and name what you need. Never praise. Read the business honestly.

CONTEXT
- What we sell, service or product, and the price points: [ ]
- Last three months: revenue, cost of goods or delivery, variable costs, fixed costs: [ ]
- Customers: new per month, total, churned per month, average lifetime or months retained: [ ]
- CAC by channel if known, with sales cost included: [ ]
- Last price change: when, how much, what happened to volume: [ ]
- Suppliers or stages we pay someone else for: [ ]
- Channels we own (an audience, a list, a partnership, a shelf): [ ]

THE NUMBERS
Margin: gross margin (revenue minus cost of goods, over revenue; the orange versus the juice), contribution per unit and unit economics (revenue per unit minus variable cost; never fold overhead in; volume multiplies a loss), contribution leverage (how much of the next dollar falls through). Customers: CAC payback (CAC over gross profit per customer per month; paid on day one, repaid a slice at a time out of your cash), LTV to CAC (retention moves it faster than cheaper ads), churn, net revenue retention (last year's customers this year over what they paid last year). Position: pricing power (the increase you can take against the volume you lose; the only lever that moves profit without touching cost), price elasticity (percent change in quantity over percent change in price; test on part of your traffic), commoditization (when price is the only difference), vertical integration (own a stage only if you can run it as well as the supplier), distribution advantage (reaching the next customer cheaper than anyone else; the channel is the harder half).

BUILD
1. THE MONTHLY REVIEW: one page from my statements: every number above that can be computed, with the formula and the value, then the three that need attention, each with what owners assume, what it is costing me, and one action this month.
2. THE HONEST READ: one paragraph on whether this business is real at this scale, and what would make it more real.
3. THE PAYBACK RULE: the CAC I should never spend past given my gross profit per customer per month and how long customers stay, with the math.
4. THE PRICING TEST: a thirty-day plan to raise the price on a slice of customers or traffic, what to measure, and the result that means raise it for everyone.
5. THE TERM SHEET: forty business terms (the thirteen above plus twenty-seven you choose for my situation) in the card format: the math, the mechanism, do not, the tell, what it costs, what owners assume, where it shows up, with one service-business and one product-business example each. Use my numbers where I gave them.
6. QUIZ MODE: forty questions with an answer key and a scoring guide (what a score under 25 means, 25 to 32, over 32).

Rules: plain language, no dashes, no praise, mark assumptions [CHECK].
```

## 1. Margin first

```
MONTHLY REVIEW. From these statements, compute every business number you can, list the three that need attention with what owners assume and what it costs me, and give one action each. No praise. STATEMENTS: [paste]
```
