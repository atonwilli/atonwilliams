# Marketing Math, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are building a marketing numbers system for an owner who does not run the ads personally but needs to know whether they are working. Read CONTEXT, then THE NUMBERS, then follow BUILD. Ask me up to five questions first. Use only the data I give. If a number cannot be computed, say so and name the column needed.

CONTEXT
- What we sell, the value of a customer, and how long they stay: [ ]
- Who runs our ads (me, an employee, an agency) and what they report today: [ ]
- Platforms and monthly spend: [ ]
- The optimization event per campaign and the attribution window in use: [ ]
- Our funnel stages and any rates we track (apply, book, show, close): [ ]
- An export from the ad platform (paste or describe columns): [ ]
- Our sales numbers for the same period, from our own records: [ ]

THE NUMBERS
Cost: ROAS (revenue from ads over spend; never call above 1.0 profitable), CAC (ad spend plus sales cost over new customers; the whole cost, not just the ads), CPM, CPC (the first number reflecting a viewer's decision; a cheap click next to an expensive result means the page is the problem), CPR (per optimization event; never compare across different events; rising cost with falling volume is the earliest honest sign of tiring). Counting: attribution windows (a counting rule about time, not a claim of cause; the ledger you keep is the scoreboard), conversions API and match rate (server-sent events; never send the same conversion from browser and server without a shared identifier), schedule events (booked calls sent back; optimize for the booked call, not the application), media mix modeling (measure a channel by what happens when you move its spend; never on one month). Creative: fatigue (cost rising and volume falling together; duplicate with nothing changed and give it three days before blaming the creative), diversity (distinct concepts over active ads; edits are not concepts), frequency capping (impressions over reach; a dosage, not a punishment). Funnel: clicks x apply x book x show x close; fix the stage losing the most people, not the cheapest; back-end selling systems are what make the front-end math work.

BUILD
1. THE WEEKLY READ from my export: the cost numbers, the tells (yes or no with the numbers), creative diversity, the funnel with the stage losing the most, and the one fix.
2. THE FIFTEEN-MINUTE AUDIT: a checklist I can run every Monday from the report my ad person sends, with the number to look at and the question to ask for each item.
3. THE AGENCY-HONESTY TEST: ten questions to ask whoever runs my ads, the answer that is fine, and the answer that should worry me.
4. THE TERM SHEET: forty marketing terms (the fifteen above plus twenty-five more you choose for my situation) in the card format: the math, the mechanism, do not, the tell, what it costs, what owners assume, where it shows up. Use my numbers in the examples wherever I gave them.
5. MY LEDGER: the columns of the sales ledger I should keep myself so the platform count is a delivery signal and my ledger is the scoreboard.
6. QUIZ MODE: forty questions in three levels with an answer key.

Rules: plain language, no jargon without a one-line definition, no dashes, mark assumptions [CHECK].
```

## 1. The card format

```
WEEKLY READ. From this export and these sales numbers, produce the one-page read: cost numbers, tells, diversity, funnel, one fix. Say which file and date range you used. Never estimate a missing metric. EXPORT: [paste]  SALES: [paste]
```
