# GitHub for Operators, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## 1. Setup in twenty minutes

```
git status              What changed since the last snapshot? Run this constantly.
git add .               Stage everything that changed, ready to be snapshotted.
git commit -m "..."     Take the snapshot with a message.
git push                Send your snapshots to GitHub.
git pull                Get everyone else's snapshots from GitHub.
git log --oneline       The history, one line per snapshot.
git diff                Exactly what changed, line by line, not yet committed.
git checkout -b name    Start a branch: a parallel copy to work on safely.
git switch main         Go back to the main copy.
git merge name          Bring a branch's changes into the copy you are on.
git restore file.md     Throw away uncommitted changes to one file.
git stash               Set aside uncommitted changes without losing them.
```

## 3. Conventions that keep it clean

```
## What this changes
[one or two lines]

## Why
[the reason, or the decision it comes from]

## How to check it
[what a reviewer should read or run]

## Anything the brain file needs to learn from this?
[yes: what / no]
```

## 4. Running a business on GitHub

```
/operations
  README.md                  What this repo is and how to use it
  BRAIN.md                   The brain file
  DECISIONS.md               The decisions log
  VOICE.md                   The voice guide
  /skills                    Reusable AI skills
  /sops                      One file per procedure
    2026-09-tune-up-checklist.md
    2026-08-new-hire-week-one.md
  /content
    /notes                   Drafts and published notes, date-first names
    /posts                   Social posts by week
    CALENDAR.md              What publishes when
  /reports
    /weekly                  2026-W36.md, 2026-W37.md
  /templates                 Proposal, email, job post shells
```

## 5. Recovery recipes

```
Explain this diff to a non-technical owner in plain language. What changed, why it probably changed, and anything that looks risky or contradicts the brain file. Under 150 words. If a line changes a number, a price, a date, or a claim, quote it.

DIFF:
[paste from git diff or the PR]
```

## Prompt B. Write the PR description

```
Write a pull request description for these changes using this template: What this changes (two lines), Why (one line or the decision it comes from), How to check it (specific files to read), Anything the brain file needs to learn from this (yes with the addition, or no). Use only what is in the diff.

DIFF:
[paste]
```

## Prompt C. Git recovery helper

```
I am not a developer. Here is my git status and recent log. Tell me, in numbered steps, exactly what to run to get back to a clean working state without losing any uncommitted work. Explain what each command does in one sentence. If any step could lose work, say so before the step and give me the safer alternative.

STATUS:
[paste git status]
LOG:
[paste git log --oneline -5]
WHAT I WAS TRYING TO DO:
[one sentence]
```
