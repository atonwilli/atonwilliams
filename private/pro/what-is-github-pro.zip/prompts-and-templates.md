# GitHub for Operators, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are setting up GitHub for a small business that will use it for text, not just code: SOPs, a brain file, content, reports, and AI-proposed changes reviewed by a human. Read CONTEXT, then follow BUILD. Ask me up to five questions first if anything is unclear. Assume I am not a developer unless CONTEXT says otherwise.

CONTEXT
- My comfort with a terminal (none, some, comfortable): [ ]
- Computer (Mac or Windows): [ ]
- Do I already have a GitHub account and any repositories: [ ]
- What will live in the repository (brain file, SOPs, content, reports, other): [ ]
- Who else needs access and what they should be able to do: [ ]
- The AI tools that will read or write these files: [ ]
- Does a website read from this repository, or will it: [ ]
- How often content or documents change: [ ]

BUILD
1. SETUP: numbered steps for my computer and comfort level to get from nothing to a private repository with the first file committed and pushed, including two-factor authentication. If I said "none" for terminal, use GitHub Desktop only.
2. THE STRUCTURE: the folder layout for what will live here, with a one-line purpose per folder and file naming rules (date-first).
3. README.md for the repository, written for my team.
4. CONVENTIONS: commit message rule, branch naming, and a pull request template saved at .github/pull_request_template.md.
5. THE WEEKLY FLOW: how a change goes from an AI draft on a branch, to a pull request, to my review on my phone, to a merge, in numbered steps.
6. THE CHEAT SHEET: only the commands (or Desktop buttons) I will actually use, each with one plain sentence on what it does.
7. RECOVERY: the five situations most likely to scare me (undo a change, restore an old version, find who changed a line, set work aside, "it is broken and I do not know why") with the exact steps for each.
8. THREE PROMPTS I can paste later: explain this change to me plainly, write this pull request description, and help me recover from this git state.

Rules: plain language, no jargon without a one-line definition, no dashes. If a step could lose work, say so before the step and give the safer alternative.
```

## 1. Setup in twenty minutes

```
git status              What changed since the last snapshot? Run this constantly.
git add .               Stage everything that changed, ready to be snapshotted.
git commit -m "..."     Take the snapshot with a message.
git push                Send your snapshots to GitHub.
git pull                Get everyone else's snapshots from GitHub.
git log --oneline       The history, one line per snapshot.
git diff                Exactly what changed, line by line, not yet committed.
git checkout -b name    Start a branch: a parallel copy to work on safely.
git switch main         Go back to the main copy.
git merge name          Bring a branch's changes into the copy you are on.
git restore file.md     Throw away uncommitted changes to one file.
git stash               Set aside uncommitted changes without losing them.
```

## 3. Conventions that keep it clean

```
## What this changes
[one or two lines]

## Why
[the reason, or the decision it comes from]

## How to check it
[what a reviewer should read or run]

## Anything the brain file needs to learn from this?
[yes: what / no]
```

## 4. Running a business on GitHub

```
/operations
  README.md                  What this repo is and how to use it
  BRAIN.md                   The brain file
  DECISIONS.md               The decisions log
  VOICE.md                   The voice guide
  /skills                    Reusable AI skills
  /sops                      One file per procedure
    2026-09-tune-up-checklist.md
    2026-08-new-hire-week-one.md
  /content
    /notes                   Drafts and published notes, date-first names
    /posts                   Social posts by week
    CALENDAR.md              What publishes when
  /reports
    /weekly                  2026-W36.md, 2026-W37.md
  /templates                 Proposal, email, job post shells
```

## 5. Recovery recipes

```
Explain this diff to a non-technical owner in plain language. What changed, why it probably changed, and anything that looks risky or contradicts the brain file. Under 150 words. If a line changes a number, a price, a date, or a claim, quote it.

DIFF:
[paste from git diff or the PR]
```

## Prompt B. Write the PR description

```
Write a pull request description for these changes using this template: What this changes (two lines), Why (one line or the decision it comes from), How to check it (specific files to read), Anything the brain file needs to learn from this (yes with the addition, or no). Use only what is in the diff.

DIFF:
[paste]
```

## Prompt C. Git recovery helper

```
I am not a developer. Here is my git status and recent log. Tell me, in numbered steps, exactly what to run to get back to a clean working state without losing any uncommitted work. Explain what each command does in one sentence. If any step could lose work, say so before the step and give me the safer alternative.

STATUS:
[paste git status]
LOG:
[paste git log --oneline -5]
WHAT I WAS TRYING TO DO:
[one sentence]
```
