# The Five Seats, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are building the five-seat structure for my business. Read CONTEXT, then THE SEATS, then follow BUILD. Ask me up to five questions first. Use only what I tell you; never invent a person or a number.

CONTEXT
- What we do and our size (revenue band, customers, team): [ ]
- Every person on the team and what they actually do all week (not titles): [ ]
- What I, the owner, do all week: [ ]
- What stops or slows when I am away for two weeks: [ ]
- The numbers we track today by person, if any: [ ]
- Budget and timing for the next hire: [ ]

THE SEATS
The closer brings in the money (feed them leads, overpay the market). The operator delivers the work (makes the thing, loves the thing; one person, not four doing a quarter each). The numbers owns books, payroll, invoicing, and chasing what is already ours. The pipeline gets in front of the closer (marketing, content, partnerships). The GM manages the other four, second in command, the integrator, the seat most owners skip and the one that compounds the most. One A player per seat. A seat has an owner, one number, and a definition of done. A seat the owner sits in that someone else should own is empty. Two people each doing half of a seat is doubled.

BUILD
1. THE SEAT MAP: who sits in each seat today from what they actually do, marked filled, empty, or doubled, and the owner's own seat load.
2. FIVE SCORECARDS, one per seat, for my business: what it owns, the one number, four weekly questions the GM (or I) ask, what excellent looks like, what a warning looks like.
3. THE HANDOFFS: pipeline to closer, closer to operator, operator to numbers, everyone to numbers, and what the GM checks weekly at each handoff.
4. THE HIRING ORDER: which seat is costing the most this quarter and why, then the sequence for the next three hires.
5. THE NINETY-DAY PLAN for the next seat: the seat description, where to find the person, the two interview questions that matter, day one, day ten, day thirty, day ninety.
6. THE GM CHAPTER (if the GM seat is empty): what the GM owns and does not own, the weekly rhythm between me and the GM, the two mistakes owners make in the first ninety days, and the number the GM is measured on.
7. QUIZ MODE: fifteen short situations; for each, which seat is empty or doubled.

Rules: plain language, no dashes, mark assumptions [CHECK].
```

## 1. Why five

```
SEAT MAP. From this list of people and what they actually do, place each in a seat, mark each seat filled, empty, or doubled, and tell me which seat I am sitting in that someone else should own. PEOPLE: [paste]
```
