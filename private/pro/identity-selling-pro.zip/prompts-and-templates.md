# Identity-Based Selling, Pro: prompts and templates

Copy and paste. Replace anything in [brackets].

## Start here: the build prompt

```
You are building an identity-based selling system for my product. Read CONTEXT, then THE METHOD, then follow BUILD. Ask me up to five questions first about anything blank. Use only my product facts. Never invent a customer, a result, or a capability.

CONTEXT
- What we sell and the verified facts (does, costs, included, NOT included): [ ]
- Claims we can make: [ ]   Claims we never make: [ ]
- Medium (retail or events, phone, meetings, or a mix): [ ]
- Two or three customer types we actually meet, and what each says they want: [ ]
- Proof we have today (customers like them, results we can show, examples): [ ]
- Words we use: [ ]   Words we never use: [ ]

THE METHOD
A purchase does two jobs: solves a practical problem and expresses an identity. Reputation answers "can I trust it," features answer "what can it do," and the missing question is "is this for someone like me." Three layers under every product: what it is, what it lets me do, who I can become. The framework has four parts in order: DESIRED SELF (found in discovery, in their words), BEHAVIOR (the action that person takes that the product supports), PRODUCT (the one feature that supports the behavior, its role stated before any list), PROOF (a believable version of who they want to become, one step ahead, never ten). Sell a better version of the customer as a staircase (start, practice, progress, identity), never an instant identity. Step outside the sale: claim, demonstration, application; give them something useful before you ask.

BUILD
1. THE MAP: for each customer type, desired self, behavior, product, proof, each in one or two lines.
2. THE THREE LAYERS for the wall: what it is, what it lets me do, who I can become, one sentence each.
3. LINES FOR MY MEDIUM: for each customer type, one discovery question that surfaces the desired self and one show line that ties the product to the behavior. If we use several mediums, do each.
4. THE PROOF LADDER: what we can prove today, what we should collect this month, and the exact ask to get it (a permissioned quote, a before-and-after, a first-week win).
5. THE IDENTITY OBJECTION: what to say when the customer says "that is not me," rebuilt through the three layers.
6. THE PAGE OR AD VERSION: a headline, three lines, and a call to action that lead with the desired self and end with the product.
7. QUIZ MODE: twelve short customer statements; for each, the desired self hidden in it.

Rules: plain language, no hype, no dashes, mark anything you had to assume as [CHECK].
```

## 1. Why features lose

```
IDENTITY CRITIC. Grade this pitch: does it name a desired self in the customer's words, a behavior, one feature tied to that behavior, and proof one step ahead? Quote the line where it slips into features. Rewrite the weakest part. PITCH: [paste]
```
