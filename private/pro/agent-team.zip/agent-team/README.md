# The Agent Team

Five agents, one folder each. Install the Operator Co-Founder first (strategic-cofounder/README.md), then the others. Point each agent's reports at the co-founder's /memory/reports folder so it can hand you one brief.

One-time purchase. Yours forever. Runs in your own Claude Code.
